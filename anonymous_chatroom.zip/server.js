const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, "public")));

const colors = ["Blue", "Red", "Green", "Purple", "Orange", "Silver", "Golden", "Quiet", "Swift", "Lucky"];
const animals = ["Fox", "Wolf", "Owl", "Tiger", "Panda", "Raven", "Bear", "Hawk", "Otter", "Cat"];

function anonymousName() {
  const word = arr => arr[Math.floor(Math.random() * arr.length)];
  return `${word(colors)}${word(animals)}${Math.floor(100 + Math.random() * 900)}`;
}

const users = new Map();
const recentMessages = new Map(); // intentionally in-memory only

io.on("connection", socket => {
  const username = anonymousName();
  users.set(socket.id, username);

  socket.emit("welcome", { username });
  io.emit("system", `${username} joined the room`);
  io.emit("online", users.size);

  socket.on("message", raw => {
    const username = users.get(socket.id);
    if (!username || typeof raw !== "string") return;

    const text = raw.trim().slice(0, 500);
    if (!text) return;

    const now = Date.now();
    const previous = recentMessages.get(socket.id) || 0;
    if (now - previous < 500) return; // basic anti-spam
    recentMessages.set(socket.id, now);

    io.emit("message", {
      username,
      text,
      time: new Date().toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"})
    });
  });

  socket.on("disconnect", () => {
    const username = users.get(socket.id);
    users.delete(socket.id);
    recentMessages.delete(socket.id);
    if (username) io.emit("system", `${username} left the room`);
    io.emit("online", users.size);
  });
});

server.listen(PORT, () => {
  console.log(`Anonymous Chatroom running at http://localhost:${PORT}`);
});