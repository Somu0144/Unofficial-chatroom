const socket = io();
const messages = document.getElementById("messages");
const form = document.getElementById("form");
const input = document.getElementById("input");
const username = document.getElementById("username");
const online = document.getElementById("online");

function addSystem(text) {
  const el = document.createElement("div");
  el.className = "system";
  el.textContent = text;
  messages.appendChild(el);
  messages.scrollTop = messages.scrollHeight;
}

function addMessage(data) {
  const wrap = document.createElement("div");
  wrap.className = "msg";

  const head = document.createElement("div");
  const name = document.createElement("span");
  name.className = "name";
  name.textContent = data.username;

  const time = document.createElement("span");
  time.className = "time";
  time.textContent = data.time;

  const text = document.createElement("div");
  text.className = "text";
  text.textContent = data.text; // prevents HTML injection

  head.append(name, time);
  wrap.append(head, text);
  messages.appendChild(wrap);
  messages.scrollTop = messages.scrollHeight;
}

socket.on("welcome", data => username.textContent = data.username);
socket.on("online", count => online.textContent = count);
socket.on("system", addSystem);
socket.on("message", addMessage);

form.addEventListener("submit", e => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  socket.emit("message", text);
  input.value = "";
  input.focus();
});